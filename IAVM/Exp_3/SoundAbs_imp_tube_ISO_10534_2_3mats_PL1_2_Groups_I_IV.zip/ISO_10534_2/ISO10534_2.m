
% UNE-EN ISO 10534-2 - Determination of sound absorption coefficient and
% impedance in impedance tubes - Part 2: Transfer-function method

function ISO10534_2

c0 = 341.2;                                                                 % Speed of sound in air [m/s]
p0 = 1.225;                                                                 % Air density [kg/m^3]

sample = 'melamine50mm'                                                     % Melamine foam 50 mm
sample = 'mineralwool50mm'                                                  % Mineral wool 50 mm
sample = 'porousconcrete40mm'                                               % Porous concrete 40 mm

switch sample                                                               % Porous sample thickness [m]
    case 'melamine50mm'
        b = 50e-3;
    case 'mineralwool50mm'
        b = 50e-3;
    case 'porousconcrete40mm'
        b = 40e-3;    
end

M = dlmread(cat(2,sample,'_I.txt'),'',4,0);                                 % Load input file for configuration I
f = M(:,1);                                                                 % Frequency vector [Hz]
H12I = 20e-6*10.^(M(:,2)/20).*exp(1j*pi/180*M(:,3));                        % Transfer function H12 for configuration I [-]
M = dlmread(cat(2,sample,'_II.txt'),'',4,0);                                % Load input file for configuration II
H12II = 20e-6*10.^(M(:,2)/20).*exp(1j*pi/180*M(:,3));                       % Transfer function H12 for configuration II [-]

d = 100e-3;                                                                 % Impedance tube inner diameter [m]
s = 50e-3;                                                                  % Spacing between microphones [m]
x1 = 310e-3 + 80e-3 - b;                                                    % Distance between sample and farthest microphone = tube section + sample holder - sample thickness [m]

fl = 0.05*c0/s;                                                             % Lowest valid frequency [Hz]
fu = min([0.58*c0/d 0.45*c0/s]);                                            % Highest valid frequency [Hz]
k0 = 2*pi*f/c0 - 1j*1.94e-2*sqrt(f)/(c0*d);                                 % Wave number [rad/m]

Hc = sqrt(H12I.*H12II);                                                     % Correction transfer function [-]
H12 = H12I./Hc;                                                             % Corrected transfer function (-)
H1 = exp(-1j*k0*s);                                                         % Incident wave transfer function [-]
HR = exp(1j*k0*s);                                                          % Reflected wave transfer function [-]
R = ((H12-H1)./(HR-H12)).*exp(2*1j*k0*x1);                                  % Reflection coefficient [-]
Zs = (p0*c0)*(1+R)./(1-R);                                                  % Specific acoustic impedance [N*s/m^3]
a = 1 - abs(R).^2;                                                          % Sound absorption coefficient [-]
[f3,a3] = third_octave_bands_average(f,a);                                  % 1/3 octave bands average
        
subplot(2,1,1),plot(f,real(Zs),'b',f,imag(Zs),'g'),hold on,xlim([fl fu]);xlabel('Hz'),ylabel('Z [N*s/m^3]'),legend('Re(Z)','Im(Z)')
subplot(2,1,2),plot(f,a,'k'),hold on,axis([fl fu -0.01 1.01]);xlabel('Hz'),ylabel('\alpha'),bar(f3,a3,'w')              
