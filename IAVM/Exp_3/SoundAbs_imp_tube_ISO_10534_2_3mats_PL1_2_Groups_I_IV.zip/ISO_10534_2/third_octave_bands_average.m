
% third_octave_bands_average - Performs a 1/3 octave bands average of a frequency spectrum

function [f3,x3] = third_octave_bands_average(f,x)

f3 = [400 500 630 800 1000 1250 1600];
f3l = f3/2^(1/6);
f3u = f3*2^(1/6);

for ii = 1:numel(f3)
    ind = f3l(ii)<f & f<f3u(ii);
    x3(ii) = mean(x(ind));
end